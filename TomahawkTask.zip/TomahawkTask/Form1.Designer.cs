﻿
namespace TomahawkTask
{
    partial class frmDownloadResource
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDownload = new System.Windows.Forms.Button();
            this.btnCancelDownload = new System.Windows.Forms.Button();
            this.lblCancelMsg = new System.Windows.Forms.Label();
            this.txtBoxContent = new System.Windows.Forms.TextBox();
            this.txtBoxContentLength = new System.Windows.Forms.TextBox();
            this.lblDownloadedResources = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnDownload
            // 
            this.btnDownload.Location = new System.Drawing.Point(15, 28);
            this.btnDownload.Name = "btnDownload";
            this.btnDownload.Size = new System.Drawing.Size(94, 29);
            this.btnDownload.TabIndex = 0;
            this.btnDownload.Text = "Download";
            this.btnDownload.UseVisualStyleBackColor = true;
            this.btnDownload.Click += new System.EventHandler(this.btnDownload_Click);
            // 
            // btnCancelDownload
            // 
            this.btnCancelDownload.Location = new System.Drawing.Point(128, 28);
            this.btnCancelDownload.Name = "btnCancelDownload";
            this.btnCancelDownload.Size = new System.Drawing.Size(143, 29);
            this.btnCancelDownload.TabIndex = 1;
            this.btnCancelDownload.Text = "Cancel Download";
            this.btnCancelDownload.UseVisualStyleBackColor = true;
            this.btnCancelDownload.Click += new System.EventHandler(this.btnCancelDownload_Click);
            // 
            // lblCancelMsg
            // 
            this.lblCancelMsg.AutoSize = true;
            this.lblCancelMsg.Location = new System.Drawing.Point(15, 71);
            this.lblCancelMsg.Name = "lblCancelMsg";
            this.lblCancelMsg.Size = new System.Drawing.Size(42, 20);
            this.lblCancelMsg.TabIndex = 2;
            this.lblCancelMsg.Text = "label";
            // 
            // txtBoxContent
            // 
            this.txtBoxContent.Location = new System.Drawing.Point(254, 115);
            this.txtBoxContent.Multiline = true;
            this.txtBoxContent.Name = "txtBoxContent";
            this.txtBoxContent.Size = new System.Drawing.Size(415, 200);
            this.txtBoxContent.TabIndex = 3;
            // 
            // txtBoxContentLength
            // 
            this.txtBoxContentLength.Location = new System.Drawing.Point(254, 347);
            this.txtBoxContentLength.Name = "txtBoxContentLength";
            this.txtBoxContentLength.Size = new System.Drawing.Size(415, 27);
            this.txtBoxContentLength.TabIndex = 4;
            // 
            // lblDownloadedResources
            // 
            this.lblDownloadedResources.AutoSize = true;
            this.lblDownloadedResources.Location = new System.Drawing.Point(15, 118);
            this.lblDownloadedResources.Name = "lblDownloadedResources";
            this.lblDownloadedResources.Size = new System.Drawing.Size(172, 20);
            this.lblDownloadedResources.TabIndex = 5;
            this.lblDownloadedResources.Text = "Downloaded Resources: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 350);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(236, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Total Length of Resource Content: ";
            // 
            // frmDownloadResource
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(690, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblDownloadedResources);
            this.Controls.Add(this.txtBoxContentLength);
            this.Controls.Add(this.txtBoxContent);
            this.Controls.Add(this.lblCancelMsg);
            this.Controls.Add(this.btnCancelDownload);
            this.Controls.Add(this.btnDownload);
            this.Name = "frmDownloadResource";
            this.Text = "Download Resource Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDownload;
        private System.Windows.Forms.Button btnCancelDownload;
        private System.Windows.Forms.Label lblCancelMsg;
        private System.Windows.Forms.TextBox txtBoxContent;
        private System.Windows.Forms.TextBox txtBoxContentLength;
        private System.Windows.Forms.Label lblDownloadedResources;
        private System.Windows.Forms.Label label1;
    }
}

