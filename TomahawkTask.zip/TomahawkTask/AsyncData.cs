﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TomahawkTask.Model;

namespace TomahawkTask
{
    class AsyncData
    {
        public static List<string> GetStaticResources()
        {
            List<string> lstResources = new List<string>();
            lstResources.Add("https://www.google.com/");
            lstResources.Add("https://stackoverflow.com/");
            lstResources.Add("https://www.c-sharpcorner.com/");
     

            return lstResources;
        }


        public static async Task<List<ResourceModel>> DownloadResourcesAsync(CancellationToken cancellationToken)
        {
            List<string> lstResources = GetStaticResources();
            List<ResourceModel> lstResourceResult = new List<ResourceModel>();

            foreach (string objResource in lstResources)
            {
                ResourceModel results = await GetResourcesAsync(objResource);
                lstResourceResult.Add(results);
                //Thread.Sleep(1000);

                if (cancellationToken.IsCancellationRequested)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    return lstResourceResult;
                }
            }

            return lstResourceResult;
        }

        private static async Task<ResourceModel> GetResourcesAsync(string url)
        {
            ResourceModel objResource = new ResourceModel();
            WebClient webClient = new WebClient();

            objResource.Url = url;
            objResource.Content = await webClient.DownloadStringTaskAsync(url);
            return objResource;
        }
    }
}
