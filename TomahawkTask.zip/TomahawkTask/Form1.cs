﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using TomahawkTask.Model;

namespace TomahawkTask
{
    public partial class frmDownloadResource : Form
    {
        CancellationTokenSource _TokenSource = null;
        List<ResourceModel> lstResourceResult;
        public frmDownloadResource()
        {
            InitializeComponent();
            lblCancelMsg.Text = string.Empty;
        }

        private async void btnDownload_Click(object sender, EventArgs e)
        {
            _TokenSource = new CancellationTokenSource();

            lblCancelMsg.Text = string.Empty;
            txtBoxContent.Text = string.Empty;
            txtBoxContentLength.Text = string.Empty;

            if (lstResourceResult != null)
                lstResourceResult.Clear();

            try
            {
                lstResourceResult = await AsyncData.DownloadResourcesAsync(_TokenSource.Token);
                ShowDownloadedResource(lstResourceResult);
            }
            catch (OperationCanceledException ex)
            {
                lblCancelMsg.Text = $"You have Cancelled the Download!";
            }
        }

        private void btnCancelDownload_Click(object sender, EventArgs e)
        {
            if (_TokenSource != null)
            {
                _TokenSource.Cancel();                
                ShowDownloadedResource(lstResourceResult);
            }
            else
                lblCancelMsg.Text = "Sorry!!! There is nothing to Cancel.";

        }
        private void ShowDownloadedResource(List<ResourceModel> lstResource)
        {
            txtBoxContent.Text = string.Empty;
            txtBoxContentLength.Text = string.Empty;

            var TotalLength = 0;

            if (lstResource != null)
            {
                foreach (var objResource in lstResource)
                {
                    txtBoxContent.Text += $"{objResource.Url}, Content length is : {objResource.Content.Length} characters long. " + Environment.NewLine;
                    TotalLength += objResource.Content.Length;
                }
                //txtBoxContentLength.Text += $"Total length of Resource Content: {TotalLength.ToString()}";
                txtBoxContentLength.Text = TotalLength.ToString();
            }
        }
    }
}
