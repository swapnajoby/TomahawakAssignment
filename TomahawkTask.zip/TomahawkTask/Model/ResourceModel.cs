﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TomahawkTask.Model
{
    class ResourceModel
    {
        public string Url { get; set; }
        public string Content { get; set; }
    }
}
